import hashlib

for a in ")P>?IJ0p./ij":
    for b in ")P>?IJ0p./ij":
        for c in ")P>?IJ0p./ij":
            for d in ")P>?IJ0p./ij":
                for e in ")P>?IJ0p./ij":
                    for f in ")P>?IJ0p./ij":
                        for g in ")P>?IJ0p./ij":
                            c_flag=a+b+c+d+e+f+g;
                            if (hashlib.sha1(c_flag).hexdigest()==b'4ce4290a0e47297a34402af8b6d33a3d283125c3'):
                                print('key found:'+c_flag)

