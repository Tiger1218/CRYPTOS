python 4.py > ./out
